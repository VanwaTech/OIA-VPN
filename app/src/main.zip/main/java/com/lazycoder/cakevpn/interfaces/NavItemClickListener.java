package com.lazycoder.cakevpn.interfaces;

public interface NavItemClickListener {
    void clickedItem(int index);
}
