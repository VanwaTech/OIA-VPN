package com.lazycoder.cakevpn.interfaces;

import com.lazycoder.cakevpn.model.Server;

public interface ChangeServer {
    void newServer(Server server);
}
